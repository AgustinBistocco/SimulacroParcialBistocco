﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RecetasSLN.dominio
{
    internal class Ingredientes
    {
        public int id_ingrediente { get; set; }
        public string ingrediente { get; set; }
        public int cantidad { get; set; }
    }
}
